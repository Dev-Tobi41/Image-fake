# Evaluation results (preset = strict, split = test)

## Overall (image level)

| Images | TP | FP | FN | TN | Accuracy | Precision | Recall | F1 | False-positive rate | Mean time/image |
|---|---|---|---|---|---|---|---|---|---|---|
| 109 | 56 | 0 | 21 | 32 | 0.807 | 1.0 | 0.727 | 0.842 | 0.0 | 0.47 s |

Mean pixel-level F1 of the localised region on correctly detected forgeries: **0.77**

## Per image category

| Category | Images | Flagged as forged | Detection rate / false-alarm rate | Mean pixel F1 |
|---|---|---|---|---|
| blur | 11 | 5 | 45% | 0.801 |
| jpeg70 | 11 | 8 | 73% | 0.781 |
| noise | 11 | 8 | 73% | 0.807 |
| original | 11 | 0 | 0% |  |
| original_jpeg75 | 7 | 0 | 0% |  |
| original_noise | 7 | 0 | 0% |  |
| original_resized | 7 | 0 | 0% |  |
| plain | 11 | 10 | 91% | 0.768 |
| rot_scale | 11 | 9 | 82% | 0.711 |
| rotate | 11 | 9 | 82% | 0.785 |
| scale | 11 | 7 | 64% | 0.753 |

## Misclassified images

| File | Truth | Predicted | Inliers |
|---|---|---|---|
| forged/chelsea_blur.png | forged | original | 0 |
| forged/clock_plain.png | forged | original | 0 |
| forged/clock_rotate.png | forged | original | 0 |
| forged/clock_scale.png | forged | original | 0 |
| forged/clock_rot_scale.png | forged | original | 0 |
| forged/clock_noise.png | forged | original | 0 |
| forged/clock_jpeg70.jpg | forged | original | 0 |
| forged/clock_blur.png | forged | original | 0 |
| forged/moon_scale.png | forged | original | 0 |
| forged/moon_jpeg70.jpg | forged | original | 0 |
| forged/moon_blur.png | forged | original | 0 |
| forged/chelsea_crop_scale.png | forged | original | 0 |
| forged/chelsea_crop_rot_scale.png | forged | original | 0 |
| forged/chelsea_crop_noise.png | forged | original | 0 |
| forged/chelsea_crop_jpeg70.jpg | forged | original | 0 |
| forged/chelsea_crop_blur.png | forged | original | 0 |
| forged/retina_crop_rotate.png | forged | original | 0 |
| forged/retina_crop_scale.png | forged | original | 0 |
| forged/retina_crop_noise.png | forged | original | 0 |
| forged/retina_crop_blur.png | forged | original | 0 |
| forged/immunohistochemistry_crop_blur.png | forged | original | 0 |
