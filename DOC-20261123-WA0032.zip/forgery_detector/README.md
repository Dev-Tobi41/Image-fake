# Digital Image Forgery Detection System (Copy-Move)

A working forgery-detection application. It analyses an uploaded JPG/JPEG/PNG image with a real
computer-vision pipeline (**SIFT → g2NN self-matching → RANSAC verification → pixel localisation**)
and highlights the duplicated regions. Nothing is random or pre-defined: the verdict is computed from the pixels.

## 1. Installation (Windows / macOS / Linux)
Requires **Python 3.9 or newer** (https://www.python.org/downloads/).

```bash
cd forgery_detector
python -m venv venv
venv\Scripts\activate            # Windows      (macOS/Linux: source venv/bin/activate)
pip install -r requirements.txt
```

## 2. Run the application
```bash
python app.py
```
Open **http://127.0.0.1:5000** in a browser. Drag an image onto the page (try the files in `sample_images/`),
press **Analyse image**, and browse the tabs: *Detection result*, *Matched features*, *Forgery mask*, *ELA*, *Original*.

Command-line use (no browser):  `python detector.py sample_images/astronaut_plain.png --out result.png`

## 3. Reproduce the testing & evaluation
```bash
python testset.py                      # builds test_data/ (originals + forged images + ground-truth masks)
python evaluate.py --split test        # held-out images  -> results/
python evaluate.py --split dev  --out results_dev
python evaluate.py --preset strict --split test --out results_strict
python -m unittest discover -s tests -v   # 10 automated unit tests
```
To test your own images: put real originals in a folder and call `detector.detect("file.jpg")`,
or use the web interface.

## 4. Files
| File | Purpose |
|---|---|
| `detector.py` | the detection algorithm (no GUI code) |
| `app.py`, `templates/index.html` | Flask web server and user interface |
| `testset.py` | creates originals and deliberately forged images with ground truth |
| `evaluate.py` | runs the detector over the test set, writes CSV / Markdown / metrics |
| `tests/test_detector.py` | automated tests |
| `results/` | documented results on the held-out test images (CSV, summary, figures) |
| `docs/` | flowchart, screenshots, `Project_Documentation.docx` |

## 5. Known limitations (be upfront about these)
* Detects **copy-move** forgery only (not splicing from another image, AI-generated or retouched content).
* Cannot find copies of smooth/featureless areas (clear sky, skin, plain walls) - no distinctive keypoints.
* Genuine repeating patterns (windows, tiles, identical objects) can still cause false alarms; the tool reports
  *evidence*, and a human should confirm.
* Mirrored (flipped) copies are not handled; heavy blur / very low-resolution images reduce recall.
