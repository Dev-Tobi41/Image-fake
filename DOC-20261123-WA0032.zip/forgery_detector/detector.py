"""
detector.py - Copy-Move Forgery Detection engine
================================================
Keypoint-based copy-move forgery detection using

    SIFT features  ->  g2NN self-matching  ->  RANSAC geometric verification
                   ->  pixel-level refinement of the duplicated regions

The module has no GUI code, so it can be used from the web app (app.py),
from the command line (python detector.py image.jpg) or from the test scripts.

Only numpy, OpenCV and Pillow are required.
"""
from __future__ import annotations

import io
import math
import time
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Tuple

import cv2
import numpy as np
from PIL import Image, ImageOps

ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png"}

# --------------------------------------------------------------------------
# Parameters
# --------------------------------------------------------------------------
@dataclass
class Params:
    max_dim: int = 1200            # larger images are down-scaled (speed)
    n_features: int = 8000         # max SIFT keypoints kept
    contrast_threshold: float = 0.01   # low value => keypoints in smooth areas too
    ratio: float = 0.6             # g2NN ratio threshold (lower = stricter)
    knn: int = 6                   # neighbours examined by g2NN
    min_dist_frac: float = 0.04    # min. distance between a matched pair (fraction of longer side)
    ransac_thresh: float = 3.0     # RANSAC reprojection error in pixels
    min_inliers: int = 8           # min. geometrically consistent matches to declare a cluster
    max_clusters: int = 6          # max. number of forged regions searched
    min_area_frac: float = 0.0015  # min. area of inlier hull (fraction of image area)
    scale_range: Tuple[float, float] = (0.5, 2.0)  # accepted scaling between copy and original
    pre_blur: float = 1.0          # Gaussian sigma applied before SIFT (suppresses noise / JPEG blocking)
    max_overlap: float = 0.25      # reject clusters whose two hulls overlap more than this (periodic structures)
    refine: bool = True            # pixel-level localisation
    diff_thresh: float = 16.0      # refinement: max mean abs. difference (0-255) to call "duplicate"


PRESETS = {
    "strict":   dict(ratio=0.50, min_inliers=12),
    "balanced": dict(ratio=0.60, min_inliers=8),
    "sensitive": dict(ratio=0.70, min_inliers=6),
}


# --------------------------------------------------------------------------
# Result containers
# --------------------------------------------------------------------------
@dataclass
class Cluster:
    index: int
    inliers: int
    shift_px: float           # distance between the two duplicated regions
    rotation_deg: float
    scale: float
    area_a_px: int
    area_b_px: int
    hull_a: list = field(default_factory=list)
    hull_b: list = field(default_factory=list)


@dataclass
class Result:
    forged: bool
    strength: str                      # "None" | "Low" | "Medium" | "High"
    message: str
    image_size: Tuple[int, int]        # processed (w, h)
    original_size: Tuple[int, int]
    n_keypoints: int = 0
    n_matches: int = 0
    n_candidate_pairs: int = 0
    n_inliers: int = 0
    clusters: List[Cluster] = field(default_factory=list)
    seconds: float = 0.0
    # images (BGR uint8) - not serialised
    img_original: Optional[np.ndarray] = None
    img_overlay: Optional[np.ndarray] = None
    img_matches: Optional[np.ndarray] = None
    img_mask: Optional[np.ndarray] = None
    mask: Optional[np.ndarray] = None  # boolean union of duplicated regions

    def summary(self) -> dict:
        d = asdict(self)
        for k in ("img_original", "img_overlay", "img_matches", "img_mask", "mask"):
            d.pop(k, None)
        return d


# --------------------------------------------------------------------------
# Image loading
# --------------------------------------------------------------------------
def load_image(source) -> np.ndarray:
    """Load an image (path, bytes or file-like) as a BGR uint8 array.
    EXIF orientation is applied and any transparency is flattened on white."""
    if isinstance(source, (bytes, bytearray)):
        source = io.BytesIO(source)
    img = Image.open(source)
    img.load()
    img = ImageOps.exif_transpose(img)
    if img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGBA")
        bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
        img = Image.alpha_composite(bg, img)
    img = img.convert("RGB")
    return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)


# --------------------------------------------------------------------------
# Core algorithm
# --------------------------------------------------------------------------
def _g2nn_matches(des: np.ndarray, ratio: float, knn: int) -> List[Tuple[int, int]]:
    """Generalised 2-nearest-neighbour test (Amerini et al., 2011).

    Every descriptor is compared with *all other* descriptors of the same image.
    For the sorted distances d1 <= d2 <= ... we look for the first index i where
    d_i / d_(i+1) < ratio: the i descriptors before this 'jump' are accepted as
    matches (they are suspiciously similar, everything after is unrelated).
    Handles regions that were copied more than once.
    """
    bf = cv2.BFMatcher(cv2.NORM_L2)
    neigh = bf.knnMatch(des, des, k=knn + 1)       # +1: the point itself
    eps = 1e-6
    pairs = []
    for row in neigh:
        q = row[0].queryIdx
        others = [m for m in row if m.trainIdx != q]
        if len(others) < 2:
            continue
        d = [m.distance for m in others]
        for i in range(len(d) - 1):
            if (d[i] + eps) / (d[i + 1] + eps) < ratio:
                for m in others[: i + 1]:
                    pairs.append((q, m.trainIdx))
                break
    return pairs


def _convex_hull(points: np.ndarray) -> np.ndarray:
    return cv2.convexHull(points.astype(np.float32).reshape(-1, 1, 2)).reshape(-1, 2)


def _hull_area(points: np.ndarray) -> float:
    if len(points) < 3:
        return 0.0
    return float(cv2.contourArea(_convex_hull(points)))


def _hull_mask(points: np.ndarray, shape, dilate_px: int) -> np.ndarray:
    m = np.zeros(shape[:2], np.uint8)
    if len(points) >= 3:
        cv2.fillConvexPoly(m, _convex_hull(points).astype(np.int32), 255)
    elif len(points) > 0:
        for p in points:
            cv2.circle(m, (int(p[0]), int(p[1])), max(3, dilate_px), 255, -1)
    if dilate_px > 0:
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * dilate_px + 1, 2 * dilate_px + 1))
        m = cv2.dilate(m, k)
    return m


def _refine_region(gray: np.ndarray, M: np.ndarray, pts_b: np.ndarray, p: Params):
    """Pixel-level localisation of the two duplicated regions A and B.

    M maps points of region A onto region B (similarity transform).  We warp the
    whole image with M so that, for a pixel y inside B, warped(y) = image(M^-1 y)
    is the pixel it was copied from.  Where |image - warped| is small, the pixel
    really is a duplicate.  The search is limited to the (dilated) hull of the
    verified keypoints so that flat/uniform areas elsewhere cannot leak in.
    """
    h, w = gray.shape
    g = gray.astype(np.float32)
    warped = cv2.warpAffine(g, M, (w, h), flags=cv2.INTER_LINEAR,
                            borderMode=cv2.BORDER_CONSTANT, borderValue=-1000)
    valid = (warped > -500)
    diff = np.abs(g - np.where(valid, warped, 0))
    diff = cv2.blur(diff, (9, 9))
    # local texture: ignore perfectly flat pixels (they match everything)
    mean = cv2.blur(g, (9, 9)); sq = cv2.blur(g * g, (9, 9))
    var = np.maximum(sq - mean * mean, 0)
    cand = (diff < p.diff_thresh) & valid & (var > 2.0)

    area = max(_hull_area(pts_b), 1.0)
    dil = int(max(6, 0.15 * math.sqrt(area)))
    bound = _hull_mask(pts_b, gray.shape, dil) > 0
    mask_b = (cand & bound).astype(np.uint8) * 255

    k5 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    mask_b = cv2.morphologyEx(mask_b, cv2.MORPH_OPEN, k5)
    mask_b = cv2.morphologyEx(mask_b, cv2.MORPH_CLOSE,
                              cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
    # keep only components that are not tiny
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask_b, connectivity=8)
    keep = np.zeros_like(mask_b)
    min_area = max(30, 0.15 * area)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            keep[lab == i] = 255
    mask_b = keep
    Minv = cv2.invertAffineTransform(M)
    mask_a = cv2.warpAffine(mask_b, Minv, (w, h), flags=cv2.INTER_NEAREST)
    return mask_a > 0, mask_b > 0


def _similarity_params(M: np.ndarray):
    a, b = M[0, 0], M[1, 0]
    scale = math.hypot(a, b)
    rot = math.degrees(math.atan2(b, a))
    return scale, rot


def detect(source, params: Optional[Params] = None, preset: Optional[str] = None) -> Result:
    """Run copy-move forgery detection on an image (path / bytes / ndarray)."""
    t0 = time.time()
    p = params or Params()
    if preset:
        for k, v in PRESETS[preset].items():
            setattr(p, k, v)

    bgr = source if isinstance(source, np.ndarray) else load_image(source)
    oh, ow = bgr.shape[:2]
    scale = min(1.0, p.max_dim / max(oh, ow))
    if scale < 1.0:
        bgr = cv2.resize(bgr, (int(round(ow * scale)), int(round(oh * scale))), interpolation=cv2.INTER_AREA)
    h, w = bgr.shape[:2]
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    gray_feat = cv2.GaussianBlur(gray, (0, 0), p.pre_blur) if p.pre_blur > 0 else gray

    res = Result(forged=False, strength="None", message="", image_size=(w, h),
                 original_size=(ow, oh), img_original=bgr.copy())
    res.img_overlay = bgr.copy()
    res.img_matches = bgr.copy()
    res.mask = np.zeros((h, w), bool)
    res.img_mask = np.zeros((h, w, 3), np.uint8)

    # 1. keypoints + descriptors ------------------------------------------------
    sift = cv2.SIFT_create(nfeatures=p.n_features, contrastThreshold=p.contrast_threshold)
    kps, des = sift.detectAndCompute(gray_feat, None)
    res.n_keypoints = 0 if kps is None else len(kps)
    if des is None or len(kps) < max(10, p.min_inliers):
        res.message = "Too few image features found (image is too small or too uniform) to analyse reliably."
        res.seconds = time.time() - t0
        return res
    pts = np.array([k.pt for k in kps], np.float32)

    # 2. g2NN self matching --------------------------------------------------------
    raw = _g2nn_matches(des, p.ratio, p.knn)
    # 3. remove matches between spatially close points ------------------------------
    min_dist = p.min_dist_frac * max(w, h)
    uniq = {}
    for i, j in raw:
        if i == j:
            continue
        key = (min(i, j), max(i, j))
        if key in uniq:
            continue
        if np.linalg.norm(pts[i] - pts[j]) >= min_dist:
            uniq[key] = True
    pairs = np.array(list(uniq.keys()), dtype=np.int32).reshape(-1, 2)
    res.n_matches = len(raw)
    res.n_candidate_pairs = len(pairs)

    # 4. RANSAC geometric verification (iterative, one transform per forged region)
    clusters_raw = []
    if len(pairs) >= p.min_inliers:
        cv2.setRNGSeed(12345)                    # reproducible results
        remaining = np.arange(len(pairs))
        for _ in range(p.max_clusters):
            if len(remaining) < p.min_inliers:
                break
            P = pts[pairs[remaining, 0]]; Q = pts[pairs[remaining, 1]]
            src = np.vstack([P, Q]); dst = np.vstack([Q, P])   # both directions
            ids = np.concatenate([np.arange(len(remaining))] * 2)
            M, inl = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC,
                                                 ransacReprojThreshold=p.ransac_thresh,
                                                 maxIters=5000, confidence=0.999)
            if M is None:
                break
            inl = inl.ravel().astype(bool)
            used = np.unique(ids[inl])
            if len(used) < p.min_inliers:
                break
            # orient every inlier pair so that A --M--> B
            a_pts, b_pts = [], []
            for loc in used:
                pi, qi = P[loc], Q[loc]
                fwd = np.linalg.norm(M[:, :2] @ pi + M[:, 2] - qi)
                bwd = np.linalg.norm(M[:, :2] @ qi + M[:, 2] - pi)
                if fwd <= bwd:
                    a_pts.append(pi); b_pts.append(qi)
                else:
                    a_pts.append(qi); b_pts.append(pi)
            a_pts = np.array(a_pts); b_pts = np.array(b_pts)
            remaining = np.delete(remaining, used)
            sc, rot = _similarity_params(M)
            shift = float(np.linalg.norm(a_pts.mean(0) - b_pts.mean(0)))
            if not (p.scale_range[0] <= sc <= p.scale_range[1]):
                continue
            if shift < min_dist:
                continue
            area_a, area_b = _hull_area(a_pts), _hull_area(b_pts)
            if min(area_a, area_b) < p.min_area_frac * w * h:
                continue
            # two hulls that overlap heavily = repeating pattern (fence, lattice, bricks), not a clone
            ha, hb = _hull_mask(a_pts, (h, w), 0) > 0, _hull_mask(b_pts, (h, w), 0) > 0
            if (ha & hb).sum() > p.max_overlap * max(1, min(ha.sum(), hb.sum())):
                continue
            clusters_raw.append((M, a_pts, b_pts, sc, rot, shift))

    # 5. build result ------------------------------------------------------------------
    palette = [(0, 0, 255), (255, 120, 0), (0, 200, 0), (200, 0, 200), (0, 200, 220), (120, 120, 255)]
    matches_img = bgr.copy()
    union = np.zeros((h, w), bool)
    color_layer = np.zeros_like(bgr)
    regions = []                                   # (idx, colour, mask_a, mask_b)
    total_inl = 0
    for idx, (M, A, B, sc, rot, shift) in enumerate(clusters_raw):
        col = palette[idx % len(palette)]
        ma = mb = None
        if p.refine:
            ma, mb = _refine_region(gray, M, B, p)
            min_px = 0.0005 * w * h
            if ma.sum() < min_px or mb.sum() < min_px:   # refinement found nothing => fall back to hull
                ma = mb = None
        if ma is None:
            dil = int(max(4, 0.05 * math.sqrt(max(_hull_area(B), 1))))
            ma = _hull_mask(A, (h, w), dil) > 0
            mb = _hull_mask(B, (h, w), dil) > 0
        union |= ma | mb
        color_layer[ma] = col
        color_layer[mb] = col
        regions.append((idx, col, ma, mb))
        for a, b in zip(A, B):
            pa, pb = tuple(int(v) for v in a), tuple(int(v) for v in b)
            cv2.line(matches_img, pa, pb, col, 1, cv2.LINE_AA)
            for pt in (pa, pb):
                cv2.circle(matches_img, pt, 4, col, -1)
                cv2.circle(matches_img, pt, 5, (255, 255, 255), 1)
        res.clusters.append(Cluster(index=idx + 1, inliers=len(A), shift_px=round(shift, 1),
                                    rotation_deg=round(rot, 1), scale=round(sc, 3),
                                    area_a_px=int(ma.sum()), area_b_px=int(mb.sum()),
                                    hull_a=_convex_hull(A).round(1).tolist(),
                                    hull_b=_convex_hull(B).round(1).tolist()))
        total_inl += len(A)

    overlay = bgr.copy()
    if union.any():
        tint = cv2.addWeighted(bgr, 0.6, color_layer, 0.4, 0)
        overlay[union] = tint[union]
    for idx, col, ma, mb in regions:
        for tag, m_ in (("A", ma), ("B", mb)):
            cnts, _ = cv2.findContours(m_.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(overlay, cnts, -1, col, 2)
            ys, xs = np.nonzero(m_)
            if len(xs):
                pos = (int(xs.min()), max(16, int(ys.min()) - 6))
                cv2.putText(overlay, f"{idx + 1}{tag}", pos, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 3, cv2.LINE_AA)
                cv2.putText(overlay, f"{idx + 1}{tag}", pos, cv2.FONT_HERSHEY_SIMPLEX, 0.6, col, 1, cv2.LINE_AA)
    res.img_overlay = overlay
    res.img_matches = matches_img
    res.mask = union
    res.img_mask = np.where(union[..., None], 255, 0).astype(np.uint8).repeat(3, axis=2)
    res.n_inliers = total_inl
    res.forged = len(res.clusters) > 0
    if res.forged:
        res.strength = "High" if total_inl >= 30 else "Medium" if total_inl >= 15 else "Low"
        res.message = (f"{len(res.clusters)} duplicated region pair(s) found, supported by "
                       f"{total_inl} geometrically consistent feature matches.")
    else:
        res.message = "No duplicated regions found. The image shows no evidence of copy-move forgery."
    res.seconds = round(time.time() - t0, 2)
    return res


# --------------------------------------------------------------------------
# Supplementary visualisation: Error Level Analysis (not used for the decision)
# --------------------------------------------------------------------------
def error_level_analysis(bgr: np.ndarray, quality: int = 90, scale: float = 15.0) -> np.ndarray:
    """Re-compress as JPEG and amplify the difference.  Regions with a different
    compression history (e.g. pasted from another image) tend to stand out."""
    ok, enc = cv2.imencode(".jpg", bgr, [cv2.IMWRITE_JPEG_QUALITY, quality])
    rec = cv2.imdecode(enc, cv2.IMREAD_COLOR)
    diff = cv2.absdiff(bgr, rec).astype(np.float32) * scale
    return np.clip(diff, 0, 255).astype(np.uint8)


# --------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse, json, os
    ap = argparse.ArgumentParser(description="Copy-move forgery detector")
    ap.add_argument("image")
    ap.add_argument("--preset", choices=PRESETS, default="balanced")
    ap.add_argument("--out", help="save annotated result image here")
    a = ap.parse_args()
    r = detect(a.image, preset=a.preset)
    print(json.dumps(r.summary(), indent=2))
    if a.out:
        cv2.imwrite(a.out, r.img_overlay)
        print("saved", a.out)
