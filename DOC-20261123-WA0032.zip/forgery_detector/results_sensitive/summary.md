# Evaluation results (preset = sensitive, split = test)

## Overall (image level)

| Images | TP | FP | FN | TN | Accuracy | Precision | Recall | F1 | False-positive rate | Mean time/image |
|---|---|---|---|---|---|---|---|---|---|---|
| 109 | 68 | 0 | 9 | 32 | 0.917 | 1.0 | 0.883 | 0.938 | 0.0 | 0.47 s |

Mean pixel-level F1 of the localised region on correctly detected forgeries: **0.784**

## Per image category

| Category | Images | Flagged as forged | Detection rate / false-alarm rate | Mean pixel F1 |
|---|---|---|---|---|
| blur | 11 | 10 | 91% | 0.7 |
| jpeg70 | 11 | 9 | 82% | 0.813 |
| noise | 11 | 10 | 91% | 0.797 |
| original | 11 | 0 | 0% |  |
| original_jpeg75 | 7 | 0 | 0% |  |
| original_noise | 7 | 0 | 0% |  |
| original_resized | 7 | 0 | 0% |  |
| plain | 11 | 10 | 91% | 0.816 |
| rot_scale | 11 | 10 | 91% | 0.787 |
| rotate | 11 | 10 | 91% | 0.789 |
| scale | 11 | 9 | 82% | 0.791 |

## Misclassified images

| File | Truth | Predicted | Inliers |
|---|---|---|---|
| forged/clock_plain.png | forged | original | 0 |
| forged/clock_rotate.png | forged | original | 0 |
| forged/clock_scale.png | forged | original | 0 |
| forged/clock_rot_scale.png | forged | original | 0 |
| forged/clock_noise.png | forged | original | 0 |
| forged/clock_jpeg70.jpg | forged | original | 0 |
| forged/clock_blur.png | forged | original | 0 |
| forged/chelsea_crop_scale.png | forged | original | 0 |
| forged/chelsea_crop_jpeg70.jpg | forged | original | 0 |
