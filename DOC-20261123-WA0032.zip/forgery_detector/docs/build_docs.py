import json, os, csv
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def M(d): return json.load(open(f"{R}/{d}/metrics.json"))["overall"]
test, dev, strict, sens = M("results"), M("results_dev"), M("results_strict"), M("results_sensitive")
rows = list(csv.DictReader(open(f"{R}/results/results.csv")))

doc = Document()
st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)
for s in doc.sections: s.left_margin = s.right_margin = Inches(1); s.top_margin = s.bottom_margin = Inches(0.9)

def H(t, l=1): doc.add_heading(t, l)
def P(t, b=False, i=False):
    p = doc.add_paragraph(); r = p.add_run(t); r.bold = b; r.italic = i; return p
def B(t):
    doc.add_paragraph(t, style="List Bullet")
def N(t):
    doc.add_paragraph(t, style="List Number")
def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), color); tcPr.append(sh)
def T(header, data, widths=None):
    t = doc.add_table(rows=1, cols=len(header)); t.style = "Table Grid"
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]; c.text = ""; r = c.paragraphs[0].add_run(h); r.bold = True; r.font.size = Pt(9.5); shade(c, "D6E4FF")
    for row in data:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""; cells[i].paragraphs[0].add_run(str(v)).font.size = Pt(9.5)
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths): row.cells[i].width = Inches(w)
    doc.add_paragraph()
def IMG(path, w=6.3, cap=None):
    doc.add_picture(path, width=Inches(w)); doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    if cap:
        p = P(cap, i=True); p.alignment = WD_ALIGN_PARAGRAPH.CENTER

# ---- title -----------------------------------------------------------------------
t = doc.add_heading("Design and Implementation of a Digital Image Forgery Detection System", 0)
P("Project documentation: design, implementation, testing and defence notes", i=True)
P("Detection method: SIFT keypoints + g2NN self-matching + RANSAC geometric verification (copy-move forgery)")

H("1. Introduction")
P("Digital images are easy to edit. One common manipulation is copy-move forgery: a region of an image is copied and "
  "pasted somewhere else in the same image, either to hide something (e.g. covering an object with a copy of the "
  "background) or to duplicate something (e.g. multiplying a crowd). Because the pasted content comes from the same "
  "photograph, its colour, noise and lighting are statistically similar to the rest of the picture, so the forgery is "
  "hard to see by eye. The key forensic clue is that the image contains two regions that are (almost) identical.")
P("This project implements software that finds such duplicated regions automatically. The earlier prototype only "
  "displayed results; this version performs a genuine image-processing analysis of the pixels of every uploaded image.")

H("2. Objectives")
for x in ["Accept JPG, JPEG and PNG images through a simple, professional interface.",
          "Detect copy-move forgery with a real algorithm that is robust to rotation, scaling, noise and JPEG compression.",
          "Highlight the suspicious regions and show the matched features that justify the decision.",
          "Evaluate the system on known original and deliberately manipulated images and document the actual results.",
          "Provide source code, installation instructions and documentation."]: B(x)

H("3. Background: how copy-move detection works")
P("Two families of methods exist:")
B("Block-based methods (Fridrich et al., 2003): slide a window over the image, compute a feature vector per block (DCT, PCA, etc.), sort the vectors and look for identical neighbours. They localise well but are weak against rotation and scaling and are computationally heavy.")
B("Keypoint-based methods (Amerini et al., 2011): detect distinctive keypoints (SIFT), describe each by a 128-number descriptor, and match keypoints against each other inside the same image. They are invariant to rotation, scaling and illumination changes, and fast. This project uses this family.")
P("SIFT (Scale-Invariant Feature Transform, Lowe 2004) finds blob-like points that look the same after the patch is rotated or resized. If a region has been cloned, its keypoints appear twice, in two places, with nearly identical descriptors.")

H("4. System design")
H("4.1 Architecture", 2)
T(["Layer", "Component", "Role"],
  [["Presentation", "templates/index.html (HTML, CSS, JavaScript)", "Upload, sensitivity selection, display of verdict, statistics, overlay, matches, mask, ELA"],
   ["Application", "app.py (Flask)", "Validates the file (type, readable, size), calls the detector, returns JSON + images"],
   ["Processing", "detector.py (OpenCV, NumPy)", "The forgery-detection algorithm"],
   ["Evaluation", "testset.py, evaluate.py, tests/", "Generates forged images with ground truth, measures accuracy, unit tests"]], [1.1, 2.4, 3.0])
H("4.2 System flowchart", 2)
IMG(f"{R}/docs/flowchart.png", 4.3, "Figure 1: Flowchart of the detection pipeline")
H("4.3 The algorithm step by step", 2)
N("Load and normalise. The file is decoded, EXIF rotation is applied, transparency is flattened, and images larger than 1200 px are shrunk (speed). A grayscale copy is smoothed with a Gaussian filter (σ = 1) so that sensor noise and JPEG block artefacts do not disturb the features.")
N("Feature extraction. SIFT (contrast threshold 0.01, up to 8000 keypoints) returns for every keypoint its position and a 128-dimensional descriptor.")
N("Self-matching with the generalised 2-nearest-neighbour test (g2NN). Each descriptor is compared with all other descriptors of the same image. With distances d1 ≤ d2 ≤ d3 …, we find the first i for which d_i / d_(i+1) < 0.6. The i descriptors before this jump are accepted as matches. (Intuition: a true duplicate is much closer than anything else.) Using more than the single nearest neighbour also copes with regions that were pasted several times.")
N("Remove trivial matches. Pairs closer than 4 % of the image size are discarded because neighbouring pixels are naturally similar.")
N("Geometric verification with RANSAC. A real clone obeys one similarity transform  q = s·R(θ)·p + t  (scale s, rotation θ, translation t) for all its keypoints. RANSAC repeatedly picks random pairs, computes the transform and counts how many matches agree (within 3 px). The best transform is kept if ≥ 8 matches support it; those matches are removed and the search repeats, so several forged regions can be found. Random false matches do not agree on a single transform and are rejected.")
N("Plausibility checks. A cluster is rejected if the scale is outside 0.5 – 2, the matched area is too small, or the two regions overlap by more than 25 % (this removes repeating structures such as a lattice tower or fence, which are not clones).")
N("Pixel-level localisation. The whole image is warped with the verified transform. For a pixel inside the pasted region B, the warped image contains the pixel it was copied from. Where the smoothed absolute difference is below 16 grey levels (and the area is textured), the pixel is marked as duplicate. The result is region A (source) and region B (copy). The algorithm cannot know which is the original, so both are highlighted.")
N("Decision. If at least one cluster survives, the image is reported as forged; the evidence strength is Low (8–14 verified matches), Medium (15–29) or High (≥ 30).")

H("4.4 Parameters", 2)
T(["Parameter", "Default", "Meaning"],
  [["ratio (g2NN)", "0.6", "Lower = stricter matching. Presets: strict 0.5, balanced 0.6, sensitive 0.7"],
   ["min_inliers", "8", "Verified matches needed to declare a forgery. Presets: 12 / 8 / 6"],
   ["pre_blur", "1.0", "Gaussian σ before SIFT; improves robustness to JPEG and noise"],
   ["ransac_thresh", "3 px", "Maximum position error for a match to agree with the transform"],
   ["min_dist_frac", "0.04", "Minimum distance between two matched points (fraction of image side)"],
   ["max_overlap", "0.25", "Maximum overlap of the two regions (rejects repeating patterns)"],
   ["diff_thresh", "16", "Pixel-difference threshold for localisation"]], [1.5, 0.8, 4.2])

H("5. Implementation")
P("Language: Python 3. Libraries: OpenCV (SIFT, matching, RANSAC, image operations), NumPy, Pillow (image decoding), Flask (web server). The detection engine (detector.py, about 400 lines) is independent of the interface, so it can be tested automatically and reused. Random-number seeding is fixed so the same image always gives the same result (reproducible, important for evaluation).")
P("Supplementary view: Error Level Analysis (ELA) re-saves the image as JPEG and amplifies the difference; it is shown as an extra visual aid but is NOT used for the decision.")

H("6. User guide and screenshots")
for i, (f, c) in enumerate([("01_home.png", "Figure 2: Start page"), ("02_uploaded.png", "Figure 3: Image selected, sensitivity chosen"),
                            ("03_forged_result.png", "Figure 4: Forged image – verdict, statistics, highlighted regions 1A/1B and table"),
                            ("04_matches.png", "Figure 5: 'Matched features' tab – lines join each keypoint to its duplicate"),
                            ("05_original_result.png", "Figure 6: Original image – no forgery detected")]):
    IMG(f"{R}/docs/screenshots/{f}", 3.8 if i in (2, 3, 4) else 5.8, c)

H("7. Testing and evaluation")
H("7.1 Test data", 2)
P("All numbers below were produced by running evaluate.py; the raw per-image results are in results/results.csv.")
B("Originals (negatives): photographs from the scikit-image library (astronaut, coffee, rocket, cat, motorcycle, camera, coins, clock, retina, moon, microscopy, deep-space image), centre-crops of some of them, plus innocent processed copies – JPEG re-saved at quality 75, with added noise, and down-sized to 80 % – which must NOT be flagged.")
B("Forged images (positives): for every original, a feathered elliptical patch (15–21 % of the image side, chosen from a textured area) was copied to another place in the same image. Seven manipulation types: plain copy, rotation (15–40°), scaling (0.8× or 1.25×), rotation+scaling, additive Gaussian noise (σ = 4), JPEG compression (quality 70), Gaussian blur.")
B("Ground truth: the exact pixel masks of the source and pasted regions are stored for every forged image.")
B("Separation of tuning and testing: the parameters were tuned using 5 'development' source images only (71 images). The final evaluation uses 7 different source images (109 images) that were never used for tuning – a fair, held-out test.")
H("7.2 Metrics", 2)
B("TP – forged image correctly flagged; TN – original correctly not flagged; FP – original wrongly flagged (false alarm); FN – forged image missed.")
B("Precision = TP/(TP+FP); Recall = TP/(TP+FN); F1 = harmonic mean; Accuracy = (TP+TN)/all; False-positive rate = FP/(FP+TN).")
B("Pixel-level F1: overlap between the detected mask and the true forged area (source + copy) on correctly detected images – measures how accurately the regions are located.")
H("7.3 Results on the held-out test set (Balanced preset)", 2)
T(["Images", "TP", "FP", "FN", "TN", "Accuracy", "Precision", "Recall", "F1", "FP rate", "Pixel F1", "Avg time"],
  [[test["n"], test["TP"], test["FP"], test["FN"], test["TN"], test["accuracy"], test["precision"], test["recall"], test["f1"],
    test["false_positive_rate"], test["mean_pixel_f1"], f'{test["mean_seconds"]} s']])
P(f"Interpretation: none of the {test['TN']} original images (including the JPEG-compressed, noisy and resized ones) was wrongly flagged, and "
  f"{test['TP']} of {test['TP'] + test['FN']} manipulated images were detected ({test['recall']*100:.0f} %). The detected regions overlap the true forged area with a pixel-level F1 of {test['mean_pixel_f1']}.")
cats = {}
for r in rows: cats.setdefault(r["attack"], []).append(r)
data = []
for a, rs in cats.items():
    flagged = sum(int(r["predicted"]) for r in rs); pf = [float(r["pix_f1"]) for r in rs if r["pix_f1"] and int(r["predicted"])]
    kind = "forged" if rs[0]["truth"] == "1" else "original"
    data.append([a, kind, len(rs), flagged, f"{flagged/len(rs):.0%}", f"{sum(pf)/len(pf):.2f}" if pf else "-"])
T(["Category", "Truth", "Images", "Flagged forged", "Rate", "Pixel F1"], data, [1.7, 0.9, 0.8, 1.2, 0.7, 0.8])
H("7.4 Development set and sensitivity presets", 2)
T(["Set / preset", "Images", "TP", "FP", "FN", "TN", "Precision", "Recall", "F1"],
  [["Development set, balanced", dev["n"], dev["TP"], dev["FP"], dev["FN"], dev["TN"], dev["precision"], dev["recall"], dev["f1"]],
   ["Test set, strict", strict["n"], strict["TP"], strict["FP"], strict["FN"], strict["TN"], strict["precision"], strict["recall"], strict["f1"]],
   ["Test set, balanced", test["n"], test["TP"], test["FP"], test["FN"], test["TN"], test["precision"], test["recall"], test["f1"]],
   ["Test set, sensitive", sens["n"], sens["TP"], sens["FP"], sens["FN"], sens["TN"], sens["precision"], sens["recall"], sens["f1"]]])
P("The presets trade recall against the risk of false alarms; on these data even the sensitive preset produced no false alarm, but on other images with repeating structures it may, which is why Balanced is the default.")
H("7.5 Examples of detection", 2)
IMG(f"{R}/docs/gallery.jpg", 6.5, "Figure 7: Original (clean) | forged input | detected regions | feature matches. Rows: plain copy, rotation+scaling, JPEG-70 compressed copy.")
H("7.6 Analysis of failures (important for the defence)", 2)
miss = [r for r in rows if r["truth"] == "1" and r["predicted"] == "0"]
P(f"The {len(miss)} missed forgeries on the test set are: " + ", ".join(r["file"].split("/")[-1] for r in miss) + ".")
B("The 'clock' image is only 300 × 400 pixels and has large smooth areas, so SIFT finds too few distinctive keypoints inside the copied patch.")
B("Strong blur removes the fine detail that SIFT relies on, so some blurred forgeries are missed.")
B("Copying a smooth, featureless area (skin, sky, plain wall) cannot be detected by any keypoint method; a manual test confirmed this.")
B("In early experiments a photo of a lattice launch tower produced a false alarm because the structure repeats naturally. The overlap rule (max_overlap) was added to handle this, and the JPEG robustness was improved by pre-smoothing. Both changes were decided on the development images only.")
H("7.7 Automated unit tests", 2)
P("tests/test_detector.py contains 10 tests (all pass): forged image detected; rotated and scaled copies detected and transform recovered; originals not flagged; verdict changes when a patch is pasted into the same photo (proof that the output is computed, not predefined); uniform image handled; results deterministic; web upload of PNG and JPG; rejection of wrong file type, corrupted file and missing file.")

H("8. Limitations and future work")
for x in ["Only copy-move forgery is detected; splicing from other images, AI-generated content and retouching need other methods (e.g. noise-inconsistency, CFA, deep learning).",
          "Smooth regions and heavy blur/low resolution reduce recall; repeated real objects can cause false alarms.",
          "Mirrored (flipped) copies are not covered (the transform model has no reflection).",
          "The test forgeries are synthetic and the originals come from a small public set. For a stronger evaluation, test on public benchmarks such as MICC-F220 / MICC-F2000, CoMoFoD or CASIA, and on your own photographs.",
          "Possible improvements: dense-field (PatchMatch) verification, flip support, combining with block-based detection for smooth areas, JPEG-aware analysis."]: B(x)

H("9. Questions your supervisor may ask – and answers")
QA = [("How do you know it is not just showing predefined results?", "The verdict comes from the pixel content: keypoints are extracted, matched and geometrically verified for each upload. Test 'test_result_is_not_predefined' pastes a patch into a photo and the verdict changes from 'clean' to 'forged'. The code has no random numbers (the RANSAC seed is fixed only for reproducibility)."),
      ("Why SIFT instead of block matching?", "SIFT descriptors are invariant to rotation, scale and brightness, so the system finds copies that were rotated or resized, which block-based DCT methods usually miss. It is also much faster."),
      ("What is the ratio test / g2NN?", "A keypoint's nearest other keypoint should be much closer than the next ones if it is a true duplicate. g2NN extends Lowe's ratio test to several copies of the same region."),
      ("Why RANSAC?", "Similar-looking but unrelated features produce random matches. A real clone moves all its points by the same transform, so RANSAC keeps only matches that agree on one transform and discards random ones. This sharply reduces false positives."),
      ("What are your results?", f"On held-out test images: precision {test['precision']}, recall {test['recall']}, F1 {test['f1']}, accuracy {test['accuracy']}, with no false alarms on {test['TN']} originals; average analysis time {test['mean_seconds']} s."),
      ("Are the results trustworthy / why not 100 %?", "No forgery detector is perfect. I report the failures and explain them (small images, blur, smooth regions). Honest reporting of limitations is part of the evaluation."),
      ("Did you tune on the test data?", "No. Parameters were tuned on 5 development images; the final numbers use 7 different images."),
      ("What does 'evidence strength' mean?", "It is the number of geometrically consistent matches: Low 8–14, Medium 15–29, High ≥ 30. It is not a probability."),
      ("Which region is the original?", "That cannot be determined from the image alone; both copies are marked 1A and 1B."),
      ("What would you do next?", "Add flip support, a smooth-region detector, benchmark datasets and other forgery types (splicing).")]
for q, a in QA:
    p = P(q, b=True); doc.add_paragraph(a)

H("10. Installation and running")
P("See README.md. Summary:")
for x in ["Install Python 3.9+.", "pip install -r requirements.txt", "python app.py", "Open http://127.0.0.1:5000 and upload an image (examples are in sample_images/).",
          "python testset.py  then  python evaluate.py --split test  to reproduce the evaluation."]: N(x)

H("References")
for x in ["Amerini, I., Ballan, L., Caldelli, R., Del Bimbo, A., Serra, G. (2011). A SIFT-based forensic method for copy-move attack detection and transformation recovery. IEEE Trans. Information Forensics and Security, 6(3).",
          "Lowe, D. G. (2004). Distinctive image features from scale-invariant keypoints. International Journal of Computer Vision, 60(2).",
          "Fischler, M. A., Bolles, R. C. (1981). Random sample consensus: a paradigm for model fitting. Communications of the ACM, 24(6).",
          "Fridrich, J., Soukal, D., Lukáš, J. (2003). Detection of copy-move forgery in digital images. Digital Forensic Research Workshop.",
          "Christlein, V., Riess, C., Jordan, J., Riess, C., Angelopoulou, E. (2012). An evaluation of popular copy-move forgery detection approaches. IEEE TIFS, 7(6).",
          "Bradski, G. (2000). The OpenCV Library. Dr. Dobb's Journal of Software Tools."]: B(x)
doc.save(f"{R}/docs/Project_Documentation.docx"); print("saved")
