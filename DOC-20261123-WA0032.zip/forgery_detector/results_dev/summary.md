# Evaluation results (preset = balanced, split = dev)

## Overall (image level)

| Images | TP | FP | FN | TN | Accuracy | Precision | Recall | F1 | False-positive rate | Mean time/image |
|---|---|---|---|---|---|---|---|---|---|---|
| 71 | 43 | 0 | 6 | 22 | 0.915 | 1.0 | 0.878 | 0.935 | 0.0 | 0.19 s |

Mean pixel-level F1 of the localised region on correctly detected forgeries: **0.702**

## Per image category

| Category | Images | Flagged as forged | Detection rate / false-alarm rate | Mean pixel F1 |
|---|---|---|---|---|
| blur | 7 | 6 | 86% | 0.695 |
| jpeg70 | 7 | 5 | 71% | 0.7 |
| noise | 7 | 7 | 100% | 0.709 |
| original | 7 | 0 | 0% |  |
| original_jpeg75 | 5 | 0 | 0% |  |
| original_noise | 5 | 0 | 0% |  |
| original_resized | 5 | 0 | 0% |  |
| plain | 7 | 7 | 100% | 0.764 |
| rot_scale | 7 | 6 | 86% | 0.725 |
| rotate | 7 | 6 | 86% | 0.692 |
| scale | 7 | 6 | 86% | 0.619 |

## Misclassified images

| File | Truth | Predicted | Inliers |
|---|---|---|---|
| forged/coffee_rot_scale.png | forged | original | 0 |
| forged/rocket_rotate.png | forged | original | 0 |
| forged/coins_jpeg70.jpg | forged | original | 0 |
| forged/coffee_crop_scale.png | forged | original | 0 |
| forged/coffee_crop_jpeg70.jpg | forged | original | 0 |
| forged/coffee_crop_blur.png | forged | original | 0 |
