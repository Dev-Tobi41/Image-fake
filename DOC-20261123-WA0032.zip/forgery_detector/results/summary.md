# Evaluation results (preset = balanced, split = test)

## Overall (image level)

| Images | TP | FP | FN | TN | Accuracy | Precision | Recall | F1 | False-positive rate | Mean time/image |
|---|---|---|---|---|---|---|---|---|---|---|
| 109 | 64 | 0 | 13 | 32 | 0.881 | 1.0 | 0.831 | 0.908 | 0.0 | 0.5 s |

Mean pixel-level F1 of the localised region on correctly detected forgeries: **0.78**

## Per image category

| Category | Images | Flagged as forged | Detection rate / false-alarm rate | Mean pixel F1 |
|---|---|---|---|---|
| blur | 11 | 7 | 64% | 0.751 |
| jpeg70 | 11 | 9 | 82% | 0.795 |
| noise | 11 | 10 | 91% | 0.777 |
| original | 11 | 0 | 0% |  |
| original_jpeg75 | 7 | 0 | 0% |  |
| original_noise | 7 | 0 | 0% |  |
| original_resized | 7 | 0 | 0% |  |
| plain | 11 | 10 | 91% | 0.792 |
| rot_scale | 11 | 10 | 91% | 0.764 |
| rotate | 11 | 9 | 82% | 0.814 |
| scale | 11 | 9 | 82% | 0.761 |

## Misclassified images

| File | Truth | Predicted | Inliers |
|---|---|---|---|
| forged/chelsea_blur.png | forged | original | 0 |
| forged/clock_plain.png | forged | original | 0 |
| forged/clock_rotate.png | forged | original | 0 |
| forged/clock_scale.png | forged | original | 0 |
| forged/clock_rot_scale.png | forged | original | 0 |
| forged/clock_noise.png | forged | original | 0 |
| forged/clock_jpeg70.jpg | forged | original | 0 |
| forged/clock_blur.png | forged | original | 0 |
| forged/moon_blur.png | forged | original | 0 |
| forged/chelsea_crop_scale.png | forged | original | 0 |
| forged/chelsea_crop_jpeg70.jpg | forged | original | 0 |
| forged/retina_crop_rotate.png | forged | original | 0 |
| forged/retina_crop_blur.png | forged | original | 0 |
