"""
app.py - web interface for the Copy-Move Forgery Detection System
Run:  python app.py      then open  http://127.0.0.1:5000
"""
import base64
import os

import cv2
from flask import Flask, jsonify, render_template, request

import detector

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024      # 25 MB upload limit


def _b64(img, ext=".jpg"):
    params = [cv2.IMWRITE_JPEG_QUALITY, 90] if ext == ".jpg" else []
    ok, buf = cv2.imencode(ext, img, params)
    mime = "image/jpeg" if ext == ".jpg" else "image/png"
    return f"data:{mime};base64," + base64.b64encode(buf.tobytes()).decode()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/analyze", methods=["POST"])
def analyze():
    f = request.files.get("image")
    if f is None or f.filename == "":
        return jsonify(error="No file selected. Please choose a JPG, JPEG or PNG image."), 400
    ext = os.path.splitext(f.filename)[1].lower().lstrip(".")
    if ext not in detector.ALLOWED_EXTENSIONS:
        return jsonify(error=f"Unsupported file type '.{ext}'. Only JPG, JPEG and PNG are allowed."), 400
    preset = request.form.get("preset", "balanced")
    if preset not in detector.PRESETS:
        preset = "balanced"
    data = f.read()
    try:
        bgr = detector.load_image(data)
    except Exception:
        return jsonify(error="The file could not be read as an image. It may be corrupted."), 400
    if min(bgr.shape[:2]) < 64:
        return jsonify(error="Image is too small (minimum 64 x 64 pixels)."), 400
    try:
        r = detector.detect(bgr, preset=preset)
    except Exception as e:                                   # never crash the UI
        return jsonify(error=f"Analysis failed: {e}"), 500
    out = r.summary()
    out["preset"] = preset
    out["images"] = {
        "original": _b64(r.img_original),
        "overlay": _b64(r.img_overlay),
        "matches": _b64(r.img_matches),
        "mask": _b64(r.img_mask, ".png"),
        "ela": _b64(detector.error_level_analysis(r.img_original)),
    }
    for c in out["clusters"]:                                # keep payload small
        c.pop("hull_a", None); c.pop("hull_b", None)
    out["filename"] = f.filename
    return jsonify(out)


@app.errorhandler(413)
def too_large(_):
    return jsonify(error="File too large (maximum 25 MB)."), 413


if __name__ == "__main__":
    print("Open http://127.0.0.1:5000 in your browser")
    app.run(host="127.0.0.1", port=5000, debug=False)
