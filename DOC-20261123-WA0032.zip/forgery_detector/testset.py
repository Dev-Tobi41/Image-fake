"""
testset.py - builds the evaluation data set
===========================================
* ORIGINAL images  : photographs shipped with scikit-image (no internet needed),
                     plus a centre-crop of some of them, plus "innocent" processed
                     copies (JPEG re-save, noise, resize) that must NOT be flagged.
* FORGED images    : a region is copied and pasted elsewhere in the SAME image
                     (feathered elliptical patch). Seven attack types:
                     plain, rotate, scale, rotate+scale, noise, jpeg, blur.
Ground-truth masks (source + target region) are stored for pixel-level scoring.

Run:  python testset.py            (creates ./test_data)
"""
import json, os, sys
import cv2
import numpy as np

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_data")

DEV = ["astronaut", "coffee", "rocket", "camera", "coins"]          # used to tune presets
TEST = ["chelsea", "stereo_motorcycle", "clock", "immunohistochemistry",
        "retina", "moon", "hubble_deep_field"]                      # never used for tuning


def load_base_images():
    from skimage import data
    out = {}
    for name in DEV + TEST:
        a = getattr(data, name)()
        if isinstance(a, tuple):
            a = a[0]
        if a.ndim == 2:
            a = np.stack([a] * 3, -1)
        a = a[..., :3]
        if a.dtype != np.uint8:
            a = (a * 255).astype(np.uint8) if a.max() <= 1.0 else a.astype(np.uint8)
        bgr = cv2.cvtColor(a, cv2.COLOR_RGB2BGR)
        h, w = bgr.shape[:2]
        s = min(1.0, 900 / max(h, w))
        if s < 1:
            bgr = cv2.resize(bgr, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
        out[name] = bgr
    return out


def make_copy_move(img, rng, rot=0.0, scale=1.0):
    """Return forged image + ground-truth masks (source, target)."""
    h, w = img.shape[:2]
    s = int(rng.uniform(0.15, 0.21) * min(h, w))          # patch "diameter"
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    lap = np.abs(cv2.Laplacian(gray, cv2.CV_32F))
    best, best_sc = None, -1
    for _ in range(40):                                    # textured source region
        cx = int(rng.integers(s, w - s)); cy = int(rng.integers(s, h - s))
        sc = lap[cy - s // 2: cy + s // 2, cx - s // 2: cx + s // 2].mean()
        if sc > best_sc:
            best, best_sc = (cx, cy), sc
    cx, cy = best
    src_mask = np.zeros((h, w), np.float32)
    cv2.ellipse(src_mask, (cx, cy), (s // 2, int(s * 0.42)), 0, 0, 360, 1.0, -1)
    rs = s * scale * 0.75
    for _ in range(500):                                   # target location
        tx = int(rng.integers(int(rs), w - int(rs))); ty = int(rng.integers(int(rs), h - int(rs)))
        if np.hypot(tx - cx, ty - cy) > s * (1.1 + 0.5 * scale):
            break
    M = cv2.getRotationMatrix2D((cx, cy), rot, scale)
    M[:, 2] += (tx - cx, ty - cy)
    warped = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_CUBIC)
    wmask = cv2.warpAffine(src_mask, M, (w, h), flags=cv2.INTER_LINEAR)
    alpha = cv2.GaussianBlur(wmask, (0, 0), 1.5)[..., None]
    forged = (img * (1 - alpha) + warped * alpha).round().astype(np.uint8)
    return forged, src_mask > 0.5, wmask > 0.5


def add_noise(img, rng, sigma=4.0):
    return np.clip(img.astype(np.float32) + rng.normal(0, sigma, img.shape), 0, 255).astype(np.uint8)


def build(out=OUT, seed=2024):
    rng = np.random.default_rng(seed)
    for d in ("originals", "forged", "gt"):
        os.makedirs(os.path.join(out, d), exist_ok=True)
    base = load_base_images()
    meta = []

    def save_png(path, im): cv2.imwrite(path, im)
    def save_jpg(path, im, q): cv2.imwrite(path, im, [cv2.IMWRITE_JPEG_QUALITY, q])

    items = dict(base)
    for name in ("astronaut", "coffee", "chelsea", "stereo_motorcycle", "retina", "immunohistochemistry"):
        im = base[name]; h, w = im.shape[:2]
        items[name + "_crop"] = im[int(.12 * h):int(.88 * h), int(.12 * w):int(.88 * w)].copy()

    for name, im in items.items():
        root = name.replace("_crop", "")
        split = "dev" if root in DEV else "test"
        # ---- originals (negatives) -------------------------------------------------
        variants = {"": im}
        if "_crop" not in name:
            variants["_jpeg75"] = None; variants["_noise"] = add_noise(im, rng, 3.0)
            h, w = im.shape[:2]
            variants["_resized"] = cv2.resize(im, (int(w * .8), int(h * .8)), interpolation=cv2.INTER_AREA)
        for suf, v in variants.items():
            fn = f"{name}{suf}"
            if suf == "_jpeg75":
                path = f"{out}/originals/{fn}.jpg"; save_jpg(path, im, 75)
            else:
                path = f"{out}/originals/{fn}.png"; save_png(path, v)
            meta.append(dict(file=os.path.relpath(path, out), label=0, attack="original" + (suf or ""), split=split, base=name))
        # ---- forgeries --------------------------------------------------------------
        attacks = [("plain", 0, 1.0), ("rotate", float(rng.choice([-1, 1]) * rng.uniform(15, 40)), 1.0),
                   ("scale", 0, float(rng.choice([0.8, 1.25]))), ("rot_scale", float(rng.uniform(10, 30)), 1.15),
                   ("noise", 0, 1.0), ("jpeg70", 0, 1.0), ("blur", 0, 1.0)]
        for atk, rot, sc in attacks:
            forged, ms, mt = make_copy_move(im, rng, rot, sc)
            if atk == "noise": forged = add_noise(forged, rng, 4.0)
            if atk == "blur":  forged = cv2.GaussianBlur(forged, (5, 5), 1.0)
            fn = f"{name}_{atk}"
            if atk == "jpeg70":
                path = f"{out}/forged/{fn}.jpg"; save_jpg(path, forged, 70)
            else:
                path = f"{out}/forged/{fn}.png"; save_png(path, forged)
            gt = (ms | mt).astype(np.uint8) * 255
            cv2.imwrite(f"{out}/gt/{fn}.png", gt)
            meta.append(dict(file=os.path.relpath(path, out), label=1, attack=atk, split=split, base=name,
                             gt=f"gt/{fn}.png", rot=round(rot, 1), scale=sc))
    json.dump(meta, open(f"{out}/ground_truth.json", "w"), indent=1)
    print(f"Created {sum(m['label']==0 for m in meta)} original and {sum(m['label']==1 for m in meta)} forged images in {out}")
    return meta


if __name__ == "__main__":
    build()
