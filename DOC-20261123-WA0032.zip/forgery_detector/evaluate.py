"""
evaluate.py - runs the detector on the test set and documents the results
=========================================================================
    python evaluate.py                     # uses ./test_data (create it with testset.py)
    python evaluate.py --preset strict
    python evaluate.py --split test        # only the images never used for tuning

Outputs (./results): results.csv, summary.md, metrics.json, figures/*.png
"""
import argparse, csv, json, os, time
import cv2
import numpy as np
import detector

HERE = os.path.dirname(os.path.abspath(__file__))


def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f = 2 * p * r / (p + r) if p + r else 0.0
    return p, r, f


def run(data_dir, preset, split, out_dir, save_figs=True):
    meta = json.load(open(os.path.join(data_dir, "ground_truth.json")))
    if split != "all":
        meta = [m for m in meta if m["split"] == split]
    os.makedirs(os.path.join(out_dir, "figures"), exist_ok=True)
    rows = []
    for k, m in enumerate(meta, 1):
        path = os.path.join(data_dir, m["file"])
        t = time.time()
        r = detector.detect(path, preset=preset)
        row = dict(file=m["file"], base=m["base"], split=m["split"], attack=m["attack"], truth=m["label"],
                   predicted=int(r.forged), strength=r.strength, keypoints=r.n_keypoints,
                   inliers=r.n_inliers, clusters=len(r.clusters), seconds=round(time.time() - t, 2),
                   pix_p="", pix_r="", pix_f1="")
        if m["label"] == 1 and "gt" in m:
            gt = cv2.imread(os.path.join(data_dir, m["gt"]), 0) > 127
            gt = cv2.resize(gt.astype(np.uint8), r.mask.shape[::-1], interpolation=cv2.INTER_NEAREST) > 0
            tp = int((gt & r.mask).sum()); fp = int((~gt & r.mask).sum()); fn = int((gt & ~r.mask).sum())
            p, rc, f = prf(tp, fp, fn)
            row.update(pix_p=round(p, 3), pix_r=round(rc, 3), pix_f1=round(f, 3))
        rows.append(row)
        tag = "OK " if row["truth"] == row["predicted"] else "ERR"
        print(f"[{k:3d}/{len(meta)}] {tag} {m['file']:55s} truth={row['truth']} pred={row['predicted']} inl={row['inliers']}")
        if save_figs and (row["truth"] != row["predicted"] or m["attack"] in ("plain", "rot_scale") and m["base"] in ("astronaut", "chelsea", "coffee")):
            tri = np.hstack([r.img_original, r.img_overlay, r.img_matches])
            cv2.imwrite(os.path.join(out_dir, "figures", os.path.basename(m["file"]).rsplit(".", 1)[0] + ".jpg"), tri,
                        [cv2.IMWRITE_JPEG_QUALITY, 85])
    return rows


def metrics(rows):
    tp = sum(r["truth"] == 1 and r["predicted"] == 1 for r in rows)
    fp = sum(r["truth"] == 0 and r["predicted"] == 1 for r in rows)
    fn = sum(r["truth"] == 1 and r["predicted"] == 0 for r in rows)
    tn = sum(r["truth"] == 0 and r["predicted"] == 0 for r in rows)
    p, rc, f = prf(tp, fp, fn)
    n = len(rows)
    pix = [r["pix_f1"] for r in rows if r["pix_f1"] != "" and r["predicted"] == 1]
    return dict(n=n, TP=tp, FP=fp, FN=fn, TN=tn, accuracy=round((tp + tn) / n, 3) if n else 0,
                precision=round(p, 3), recall=round(rc, 3), f1=round(f, 3),
                false_positive_rate=round(fp / (fp + tn), 3) if fp + tn else 0,
                mean_pixel_f1=round(float(np.mean(pix)), 3) if pix else 0,
                mean_seconds=round(float(np.mean([r["seconds"] for r in rows])), 2) if rows else 0)


def write_reports(rows, preset, split, out_dir):
    with open(os.path.join(out_dir, "results.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    overall = metrics(rows)
    by_attack = {}
    for a in sorted({r["attack"] for r in rows}):
        sub = [r for r in rows if r["attack"] == a]
        if sub[0]["truth"] == 1:
            by_attack[a] = (len(sub), sum(r["predicted"] for r in sub),
                            np.mean([r["pix_f1"] for r in sub if r["pix_f1"] != "" and r["predicted"]] or [0]))
        else:
            by_attack[a] = (len(sub), sum(r["predicted"] for r in sub), None)
    json.dump(dict(preset=preset, split=split, overall=overall), open(os.path.join(out_dir, "metrics.json"), "w"), indent=1)
    L = [f"# Evaluation results (preset = {preset}, split = {split})", "",
         "## Overall (image level)", "",
         "| Images | TP | FP | FN | TN | Accuracy | Precision | Recall | F1 | False-positive rate | Mean time/image |",
         "|---|---|---|---|---|---|---|---|---|---|---|",
         f"| {overall['n']} | {overall['TP']} | {overall['FP']} | {overall['FN']} | {overall['TN']} | {overall['accuracy']} | "
         f"{overall['precision']} | {overall['recall']} | {overall['f1']} | {overall['false_positive_rate']} | {overall['mean_seconds']} s |",
         "", f"Mean pixel-level F1 of the localised region on correctly detected forgeries: **{overall['mean_pixel_f1']}**", "",
         "## Per image category", "",
         "| Category | Images | Flagged as forged | Detection rate / false-alarm rate | Mean pixel F1 |", "|---|---|---|---|---|"]
    for a, (n, flagged, pf) in by_attack.items():
        L.append(f"| {a} | {n} | {flagged} | {flagged / n:.0%} | {'' if pf is None else round(float(pf), 3)} |")
    L += ["", "## Misclassified images", "", "| File | Truth | Predicted | Inliers |", "|---|---|---|---|"]
    for r in rows:
        if r["truth"] != r["predicted"]:
            L.append(f"| {r['file']} | {'forged' if r['truth'] else 'original'} | {'forged' if r['predicted'] else 'original'} | {r['inliers']} |")
    open(os.path.join(out_dir, "summary.md"), "w").write("\n".join(L) + "\n")
    return overall


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=os.path.join(HERE, "test_data"))
    ap.add_argument("--preset", default="balanced", choices=detector.PRESETS)
    ap.add_argument("--split", default="all", choices=["all", "dev", "test"])
    ap.add_argument("--out", default=os.path.join(HERE, "results"))
    ap.add_argument("--no-figs", action="store_true")
    a = ap.parse_args()
    rows = run(a.data, a.preset, a.split, a.out, not a.no_figs)
    print(json.dumps(write_reports(rows, a.preset, a.split, a.out), indent=1))
