"""Automated tests.  Run:  python -m unittest discover -s tests -v"""
import io, os, sys, unittest
import cv2, numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import detector
from app import app

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S = os.path.join(ROOT, "sample_images")


class TestDetector(unittest.TestCase):
    def test_forged_detected(self):
        r = detector.detect(os.path.join(S, "astronaut_plain.png"))
        self.assertTrue(r.forged); self.assertGreaterEqual(r.n_inliers, 8)
        self.assertTrue(r.mask.any())

    def test_rotated_copy_detected_and_angle_recovered(self):
        r = detector.detect(os.path.join(S, "chelsea_rotate.png"))
        self.assertTrue(r.forged)
        self.assertGreater(abs(r.clusters[0].rotation_deg), 10)       # rotation was 15-40 degrees

    def test_scaled_copy_detected(self):
        r = detector.detect(os.path.join(S, "coffee_scale.png"))
        self.assertTrue(r.forged)
        self.assertGreater(abs(r.clusters[0].scale - 1.0), 0.1)

    def test_original_not_flagged(self):
        for f in ("astronaut.png", "chelsea.png"):
            self.assertFalse(detector.detect(os.path.join(S, f)).forged, f)

    def test_result_is_not_predefined(self):
        """Same photo, with / without a pasted patch -> different verdicts."""
        img = detector.load_image(os.path.join(S, "astronaut.png"))
        forged = img.copy()
        forged[60:140, 380:460] = img[300:380, 150:230]      # copy a textured patch (suit badge area)
        self.assertTrue(detector.detect(forged).forged)
        self.assertFalse(detector.detect(img).forged)

    def test_uniform_image_inconclusive(self):
        r = detector.detect(np.full((300, 300, 3), 120, np.uint8))
        self.assertFalse(r.forged)

    def test_deterministic(self):
        a = detector.detect(os.path.join(S, "astronaut_plain.png"))
        b = detector.detect(os.path.join(S, "astronaut_plain.png"))
        self.assertEqual(a.n_inliers, b.n_inliers)


class TestWebApp(unittest.TestCase):
    def setUp(self): self.c = app.test_client()

    def post(self, name, data):
        return self.c.post("/api/analyze", data={"image": (io.BytesIO(data), name)}, content_type="multipart/form-data")

    def test_pages_and_upload(self):
        self.assertEqual(self.c.get("/").status_code, 200)
        r = self.post("x.png", open(os.path.join(S, "astronaut_plain.png"), "rb").read())
        self.assertEqual(r.status_code, 200); self.assertTrue(r.get_json()["forged"])

    def test_jpg_upload(self):
        r = self.post("x.jpg", open(os.path.join(S, "stereo_motorcycle_jpeg70.jpg"), "rb").read())
        self.assertEqual(r.status_code, 200)

    def test_rejects_bad_type_and_corrupt(self):
        self.assertEqual(self.post("x.gif", b"GIF89a").status_code, 400)
        self.assertEqual(self.post("x.jpg", b"not an image").status_code, 400)
        self.assertEqual(self.c.post("/api/analyze", data={}).status_code, 400)


if __name__ == "__main__":
    unittest.main()
